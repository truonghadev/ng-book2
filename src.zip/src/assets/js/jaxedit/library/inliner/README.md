Inliner
=======

Inliner is a tiny css and javascript library for modern browsers. You could get it from [https://github.com/zohooo/inliner](https://github.com/zohooo/inliner).
