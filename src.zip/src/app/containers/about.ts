import { Component } from '@angular/core';

@Component({
  selector: 'about-container',
  template: `
    <div class="about-container">
      <h1>about page</h1>
    </div>
  `
})
export class About {}
