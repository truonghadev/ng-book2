export class Message{
    constructor(public name: String, public data: any){
        
    }
}