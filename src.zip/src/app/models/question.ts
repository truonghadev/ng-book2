import {QuestionAnswer} from './question-answer';
import {UUID} from 'angular2-uuid';

export class Question{
    public id: string;
    public type: number;
    public image: string;
    public answers: Array<QuestionAnswer>;
    public content: string;
    public desciption: string;
    public showOptions: any = {
        desciption: false,
        redirect: false,
        shuffle: false,
        includeHours: false,
        includeYear: false,
        time: false,
        duration: false,
        confirm: false
    };

    constructor(id = UUID.UUID()){
        this.id = id;
        this.setType(Question.TYPES.MultipleChoise.value);
        this.answers = [new QuestionAnswer(QuestionAnswer.TYPES.Normal, "Tuỳ chọn 1")];
    }

    public static TYPES = {
        MultipleChoise: {value: 'multiple-choise', name: "Trắc nghiệm"},
        Checkbox: {value: 'checkbox', name: "Hộp kiểm"},
        DropdownMenu: {value: 'dropdown-menu', name: "Menu thả xuống"},
        ShortParagraph: {value: 'short-paragraph', name: "Trả lời ngắn"},
        Paragraph: {value: 'paragraph', name: "Đoạn"},
        Upload: {value: 'upload', name: "Tải tệp lên"},
        Date: {value: 'date', name: "Ngày"},
        Time: {value: 'time', name: "Giờ"}
    }

    public setType(toType){
        this.type = toType;
    }

    public addAnswer(answer){
        const hasOther = this.answers.find(a => a.type == QuestionAnswer.TYPES.Other);
        let other = null;
        if (hasOther){
            other = this.answers.pop();
        }
        if (!hasOther || answer.type != QuestionAnswer.TYPES.Other){
            this.answers.push(answer);
        }
        if (other) this.answers.push(other);
        return answer;
    }
}
