import { Component, OnInit, Input } from '@angular/core';
import { Question } from '../../../models';

@Component({
  selector: 'question-type-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss']
})
export class CheckboxComponent implements OnInit {
  @Input() question: Question;
  @Input() isActive: boolean;
  @Input() addAnswer: Function;
  @Input() removeAnswer: Function;
  @Input() hasOther: Function;
  @Input() initSortable: Function;
  confirms: any;
  selectedConfirm: any;
  
  constructor() { 
    setTimeout(()=>this.initSortable(), 50);
    this.confirms = [
      {value: 'selectAtLeast', name: 'Chọn ít nhất'},
      {value: 'chooseTheMost', name: 'Chọn nhiều nhất'},
      {value: 'selectTheCorrect', name: 'Chọn chính xác'}
    ];
    this.selectedConfirm = this.confirms[0];
  }

  ngOnInit() {
  }

  removeConfirm() {
    this.question.showOptions.confirm = false;
  }

}
