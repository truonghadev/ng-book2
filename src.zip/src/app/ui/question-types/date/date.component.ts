import { Component, OnInit, Input } from '@angular/core';
import { Question } from '../../../models';

@Component({
  selector: 'question-type-date',
  templateUrl: './date.component.html',
  styleUrls: ['./date.component.scss']
})
export class DateComponent implements OnInit {
  @Input() question: Question;

  constructor() { }

  ngOnInit() {
  }

}
