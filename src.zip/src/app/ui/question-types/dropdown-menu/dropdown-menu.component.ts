import { Component, OnInit, Input } from '@angular/core';
import { Question } from '../../../models';

@Component({
  selector: 'question-type-dropdown-menu',
  templateUrl: './dropdown-menu.component.html',
  styleUrls: ['./dropdown-menu.component.scss']
})
export class DropdownMenuComponent implements OnInit {
  @Input() question: Question;
  @Input() isActive: boolean;
  @Input() addAnswer: Function;
  @Input() removeAnswer: Function;
  @Input() initSortable: Function;

  constructor() { }

  ngOnInit() {
  }

}
