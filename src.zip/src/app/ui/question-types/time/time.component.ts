import { Component, OnInit, Input } from '@angular/core';
import { Question } from '../../../models';

@Component({
  selector: 'question-type-time',
  templateUrl: './time.component.html',
  styleUrls: ['./time.component.scss']
})
export class TimeComponent implements OnInit {
  @Input() question: Question;

  constructor() { }

  ngOnInit() {
  }

}
