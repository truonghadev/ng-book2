import { Component } from '@angular/core';

@Component({
  selector: 'app-bar',
  styles: [require('./app-bar.css')],
  template: require('./app-bar.html')
})
export class AppBar {}
